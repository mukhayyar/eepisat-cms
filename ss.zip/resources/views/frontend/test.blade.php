<link rel="stylesheet" href="/dist/css/frontend/styleTeamHighlight.css">
<br>
<br>
<div class="container">
    <div class="box box-1" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/iwa.png');" data-text="Iwa"></div>
    <div class="box box-2" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/dinda.png');" data-text="Dinda"></div>
    <div class="box box-3" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/faerizqi.png');" data-text="Faerizqi"></div>
    <div class="box box-4" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/reza.png');" data-text="Reza"></div>
    <div class="box box-5" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/xevanya.png');" data-text="Xevanya"></div>
    <div class="box box-6" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/sunu.png');" data-text="Sunu"></div>
    <div class="box box-7" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/fahrizal.png');" data-text="Fahrizal"></div>
    <div class="box box-8" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/nio.png');" data-text="Nio"></div>
    <div class="box box-9" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/yumna.png');" data-text="Yumna"></div>
    <div class="box box-10" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/lintang.png');" data-text="Lintang"></div>
    <div class="box box-11" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/lambang.png');" data-text="Lambang"></div>
    <div class="box box-12" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/raisha.png');" data-text="Raisha"></div>
    <div class="box box-13" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/reni.png');" data-text="Reni"></div>
    <div class="box box-14" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/danar.png');" data-text="Danar"></div>
    <div class="box box-15" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/tsabitah.png');" data-text="Tsabitah"></div>
    <div class="box box-16" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/sabrina.png');" data-text="Sabrina"></div>
    <div class="box box-17" style="--img: url('https://ik.imagekit.io/eepisat/asset/team/gen5/tsaqif.png');" data-text="Tsaqif"></div>
</div>