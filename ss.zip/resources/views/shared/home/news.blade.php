<section class="news" data-aos="fade-up">
    <div class="content">
        <h1 class="title"><strong>EEPISAT On Media</strong></h1>
        <span class="line" data-aos="fade-right" data-aos-anchor="#example-anchor"
            data-aos-duration="500"></span>
    </div>
    <div class="textSlogan">
        <p>#GarudakuJaya<br>diAngkasa</p>
    </div>
    <div class="textSloganMobile">
        <p>#GarudakuJaya<br>diAngkasa</p>
    </div>
    <div class="info">
        <!-- <div class="info1">
                 <img src="asset/sample2.webp" width="370" loading="lazy">
                 <p>Tim Dirgantara PENS Sabet Juara Umum Komurindo-Kombat 2018/2019</p>
                </div>
                <div class="info2">
                 <img src="asset/sample2.webp" width="370" loading="lazy">
                 <p>Tim Dirgantara PENS Sabet Juara Umum Komurindo-Kombat 2018/2019</p>
                </div>
                <div class="info3">
                 <img src="asset/sample2.webp" width="370" loading="lazy">
                 <p>Tim Dirgantara PENS Sabet Juara Umum Komurindo-Kombat 2018/2019</p>
                </div> -->
    </div>
</section>