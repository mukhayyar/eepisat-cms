<div class="custom-cursor" data-cursor-init="true">
    <div class="cursor-bubble" data-cursor-bubble="not-active" data-cursor-bubble-icon="scale" data-cursor-bubble-position="left">
       <div class="cursor-background"></div>
       <i class="home"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M4,11V21H20V11L12,3Z" fill="none" stroke="#000"></path></svg></i>
       <i class="chevron-left"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="15 5 8 12 15 19" fill="none" stroke="#000" stroke-miterlimit="10"></polyline></svg></i>
       <span class="cursor-text">FynnzxY£zZbaYZ</span>
       <i class="chevron-right"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="9 19 16 12 9 5" fill="none" stroke="#000" stroke-miterlimit="10"></polyline></svg></i>
       <i class="external"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="9 5 19 5 19 15" fill="none" stroke="#000" stroke-miterlimit="10"></polyline><line x1="19" y1="5" x2="6" y2="18" fill="none" stroke="#000" stroke-miterlimit="10"></line></svg></i>
       <i class="arrow-down"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="5 14 12 21 19 14" fill="none" stroke="#000" stroke-miterlimit="10"></polyline><line x1="12" y1="21" x2="12" y2="2" fill="none" stroke="#000" stroke-miterlimit="10"></line></svg></i>
       <i class="plus"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><line x1="12" y1="8" x2="12" y2="16" fill="#fff" stroke="#000" stroke-miterlimit="10"></line><line x1="16" y1="12" x2="8" y2="12" fill="#fff" stroke="#000" stroke-miterlimit="10"></line><circle cx="12" cy="12" r="10" fill="none" stroke="#000"></circle></svg></i>
       <i class="scale"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><polyline points="21 10 21 3 14 3" fill="none" stroke="#000" stroke-miterlimit="10"></polyline><line x1="21" y1="3" x2="14" y2="10" fill="none" stroke="#000" stroke-miterlimit="10"></line><polyline points="3 14 3 21 10 21" fill="none" stroke="#000" stroke-miterlimit="10"></polyline><line x1="3" y1="21" x2="9.5" y2="14.5" fill="none" stroke="#000" stroke-miterlimit="10"></line></svg></i>
    </div>
 </div>