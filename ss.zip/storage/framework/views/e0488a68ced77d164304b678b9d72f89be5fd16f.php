
<?php $__env->startSection('body'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php if(app()->environment('local')): ?>
            <?php if(Request::isSecure()): ?>
                <link rel="stylesheet" href="<?php echo e(secure_asset('dist/css/frontend/styleGallery.css')); ?>">
            <?php else: ?>
                <link rel="stylesheet" href="<?php echo e(asset('dist/css/frontend/styleGallery.css')); ?>">
            <?php endif; ?>
        <?php else: ?>
            <?php if(Request::isSecure()): ?>
                <link rel="stylesheet" href="<?php echo e(secure_asset('dist/css/frontend/styleGallery.min.css')); ?>">
            <?php else: ?>
                <link rel="stylesheet" href="<?php echo e(asset('dist/css/frontend/styleGallery.min.css')); ?>">
            <?php endif; ?>
        <?php endif; ?>
    <?php $__env->stopPush(); ?>
    <main data-aos="fade-up">
        <div class="title">
            <h1>Our Gallery</h1>
            <span class="line" data-aos="fade-right" data-aos-anchor="#example-anchor" data-aos-duration="500"></span>
        </div>
        <section class="accordion">
            <div class="accordionGen1">
                <div class="header">
                    <p>GEN 01</p><i class="ri-arrow-down-s-line"></i>
                </div>
                <div class="listImg">
                </div>
            </div>
            <div class="accordionGen2">
                <div class="header">
                    <p>GEN 02</p><i class="ri-arrow-down-s-line"></i>
                </div>
                <div class="listImg">
                </div>
            </div>
            <div class="accordionGen3">
                <div class="header">
                    <p>GEN 03</p><i class="ri-arrow-down-s-line"></i>
                </div>
                <div class="listImg">
                </div>
            </div>
            <div class="accordionGen4">
                <div class="header">
                    <p>GEN 04</p><i class="ri-arrow-down-s-line"></i>
                </div>
                <div class="listImg">
                </div>
            </div>
        </section>
    </main>
    <?php echo $__env->make('shared.frontend_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <?php $__env->startPush('scripts'); ?>
        <script src="/dist/js/frontend/accordionScript.js"></script>
        <script>
            var data = {
                galleries: [
                    [1, 2, 3],
                    [1],
                    [1],
                    [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18]
                ]
            }
            for (let i = 1; i <= 4; i++) {
                for (let j = 1; j <= data.galleries[i - 1].length; j++) {
                    document.getElementsByClassName("accordionGen" + i)[0].childNodes[3].innerHTML +=
                        `<img src="https://ik.imagekit.io/eepisat/uploads/gen0${i}/${j}.jpg" loading="lazy">`;
                }
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projek 2024\eepisat-cms-old-php\resources\views/frontend/gallery.blade.php ENDPATH**/ ?>